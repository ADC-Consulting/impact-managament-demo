/*
 * Auto-trigger ADC's production renderer on each page load:
 *  1. Wait for the React app to mount #pattern-input.
 *  2. Inject a random prompt using the React-friendly value setter.
 *  3. Click whatever button is labeled "Generate" / "Generate Patterns".
 *
 * The actual rendering, backend call, and SVG drawing are all done by
 * the production bundle (/assets/main-Bc2bcQzX.js). We are only
 * impersonating the user click.
 */

// ---------------------------------------------------------------------------
// Monkey-patch /generate to keep only 1 of the 3 returned patterns.
// The bundle's candidate-rendering path counts candidates dynamically, so
// 1 entry is fine. This kills the candidate grid AND the "X of 3" loader
// progress text at the source.
// ---------------------------------------------------------------------------
{
  const origFetch = window.fetch;
  window.fetch = async function (input, init) {
    const res = await origFetch.call(this, input, init);
    const url =
      typeof input === "string" ? input : (input && input.url) || "";
    if (!/\/generate(\?|$)/.test(url)) return res;
    let body;
    try {
      body = await res.clone().json();
    } catch {
      return res;
    }
    if (!body || typeof body.patterns !== "object") return res;
    const ids = Object.keys(body.patterns);
    if (ids.length <= 1) return res;
    const keep = ids[Math.floor(Math.random() * ids.length)];
    const filtered = { ...body, patterns: { [keep]: body.patterns[keep] } };
    return new Response(JSON.stringify(filtered), {
      status: res.status,
      statusText: res.statusText,
      headers: res.headers,
    });
  };
}

// The bundle's SvgMainRenderer hard-codes preserveAspectRatio="xMidYMid meet"
// and inline style.aspectRatio matching the chosen canvas size (Portrait A4 by
// default). Inline style wins over external CSS, and the SVG attribute can't
// be overridden by CSS at all. We watch #mainSvg and re-apply our values
// every time the bundle mutates it.
function forceFullscreenCover(svg) {
  if (!svg) return;
  svg.style.setProperty("aspect-ratio", "auto", "important");
  svg.style.setProperty("width", "100vw", "important");
  svg.style.setProperty("height", "100vh", "important");
  if (svg.getAttribute("preserveAspectRatio") !== "xMidYMid slice") {
    svg.setAttribute("preserveAspectRatio", "xMidYMid slice");
  }
}

function installSvgWatcher() {
  const svg = document.getElementById("mainSvg");
  if (!svg) return false;
  forceFullscreenCover(svg);
  const obs = new MutationObserver(() => forceFullscreenCover(svg));
  obs.observe(svg, {
    attributes: true,
    attributeFilter: ["style", "preserveAspectRatio", "width", "height"],
  });
  return true;
}

// ---------------------------------------------------------------------------
// Colour picker — overrides the bundle's fillColor by walking #mainSvg after
// every redraw and rewriting every shape's fill attribute. Decoupled from
// the bundle's internal state, so it survives any redraw the bundle does.
// ---------------------------------------------------------------------------

const PALETTE = [
  "#000000", "#2BEBCB", "#58EB81", "#A187FF",
  "#E5C574", "#FF9BFC", "#FFF347", "#ffffff",
];
const BG_PALETTE = ["#ffffff", "#1f1f1f", "#000000"];

let activeColour = "#000000";
let activeBg = "#ffffff";

function recolourSvg() {
  const svg = document.getElementById("mainSvg");
  if (!svg) return;
  // Bundle sets svg.style.background to white/black based on fillColor —
  // we want the body's background to show through instead.
  svg.style.setProperty("background", "transparent", "important");
  svg.querySelectorAll("[fill]").forEach((el) => {
    const tag = el.tagName.toLowerCase();
    if (tag === "g") return;
    if (el.getAttribute("fill") === "none") return;
    el.setAttribute("fill", activeColour);
  });
}

function applyBg() {
  // Our own CSS sets `body { background: ... !important }` as a fallback —
  // beat it with JS `important` priority.
  document.body.style.setProperty("background", activeBg, "important");
  document.documentElement.style.setProperty("background", activeBg, "important");
  // Re-tint the overlay text for legibility on light backgrounds.
  const isLight = activeBg === "#ffffff";
  document.body.dataset.bg = isLight ? "light" : "dark";
}

function buildSwatches(container, colours, onPick, isActive) {
  container.innerHTML = "";
  colours.forEach((c) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "swatch" + (isActive(c) ? " is-active" : "");
    b.style.setProperty("--c", c);
    b.dataset.colour = c;
    b.title = c;
    b.addEventListener("click", () => {
      onPick(c);
      buildSwatches(container, colours, onPick, isActive);
    });
    container.appendChild(b);
  });
}

function installColourUI() {
  buildSwatches(
    document.getElementById("palette"),
    PALETTE,
    (c) => {
      activeColour = c;
      recolourSvg();
    },
    (c) => c === activeColour,
  );
  buildSwatches(
    document.getElementById("bg-palette"),
    BG_PALETTE,
    (c) => {
      activeBg = c;
      applyBg();
    },
    (c) => c === activeBg,
  );
  applyBg();
}

function installSvgChildWatcher() {
  const svg = document.getElementById("mainSvg");
  if (!svg) return;
  const obs = new MutationObserver(() => {
    // Throttle into next animation frame so we batch a full redraw.
    if (svg.dataset.recolourPending === "1") return;
    svg.dataset.recolourPending = "1";
    requestAnimationFrame(() => {
      svg.dataset.recolourPending = "0";
      recolourSvg();
    });
  });
  obs.observe(svg, { childList: true, subtree: true });
}

const PROMPTS = [
  "ocean", "signal", "silk", "fracture", "pulse",
  "aurora", "tundra", "glass", "glow", "syntax",
  "drift", "memory", "horizon", "static", "warmth",
  "beacon", "shore", "prism", "echo", "fold",
  "ember", "lattice", "tide", "vellum", "sable",
];

function pickPrompt() {
  return PROMPTS[Math.floor(Math.random() * PROMPTS.length)];
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

// React tracks <input> / <textarea> values via its own descriptor;
// you must call the *native* setter and dispatch a bubbling 'input' event
// for React's onChange to fire.
function reactSetValue(el, value) {
  const proto =
    el instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
  setter.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

function findGenerateButton() {
  const buttons = document.querySelectorAll("button");
  let fallback = null;
  for (const b of buttons) {
    const txt = (b.textContent || "").trim().toLowerCase();
    if (txt === "generate" || txt === "generate pattern" || txt === "generate patterns") {
      if (!b.disabled) return b;
      fallback = fallback || b;
    }
  }
  return fallback;
}

function findPromptInput() {
  return (
    document.getElementById("pattern-input") ||
    document.querySelector('textarea[placeholder*="context" i]') ||
    document.querySelector('textarea[placeholder*="describe" i]')
  );
}

function waitFor(predicate, { timeoutMs = 10000, intervalMs = 80 } = {}) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const tick = () => {
      let result;
      try {
        result = predicate();
      } catch (e) {
        result = null;
      }
      if (result) return resolve(result);
      if (Date.now() - start > timeoutMs) return reject(new Error("timeout"));
      setTimeout(tick, intervalMs);
    };
    tick();
  });
}

async function autoGenerate() {
  setText("status-out", "waiting for app");
  installSvgWatcher();
  installSvgChildWatcher();
  installColourUI();

  let input;
  try {
    input = await waitFor(findPromptInput);
  } catch {
    setText("status-out", "could not find prompt input");
    return;
  }

  const prompt = pickPrompt();
  setText("prompt-out", prompt);
  reactSetValue(input, prompt);

  // Give React a tick to enable the Generate button.
  await new Promise((r) => setTimeout(r, 60));

  let button;
  try {
    button = await waitFor(() => {
      const b = findGenerateButton();
      return b && !b.disabled ? b : null;
    });
  } catch {
    setText("status-out", "generate button never enabled");
    return;
  }

  setText("status-out", "generating");
  button.click();

  // Optimistic — the backend call typically resolves in 1-3s.
  setTimeout(() => setText("status-out", "ready"), 2000);
}

// Wait for full DOMContentLoaded plus a tiny grace period so the React
// bundle has had a chance to mount its tree into #parameter-manager-container.
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => setTimeout(autoGenerate, 50));
} else {
  setTimeout(autoGenerate, 50);
}
